Auto Prompter — Shareable Builds
--------------------------------
opt/*.user.js  — Obfuscated TM userscript (local testing)
pkg/*.bin       — AES-GCM encrypted bundle (bootstrap fetches)
boot/auto-prompter-bootstrap.user.js — Bootstrap to fetch/decrypt ENC
Install bootstrap in Tampermonkey to load encrypted bundle from your public domain.
